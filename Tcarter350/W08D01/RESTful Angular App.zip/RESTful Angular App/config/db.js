module.exports = {
  uri: 'mongodb://localhost/cakeApp'
};
